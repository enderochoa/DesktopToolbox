
qx.Theme.define("demobrowser.Theme",
{
  title : "Demo browser",

  meta :
  {
    color : qx.theme.indigo.Color,
    decoration : qx.theme.indigo.Decoration,
    font : qx.theme.indigo.Font,
    icon : qx.theme.icon.Tango,
    appearance : demobrowser.Appearance
  }
});